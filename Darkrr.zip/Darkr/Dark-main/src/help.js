const help = (prefix) => {
	return `

╔════════════════════
║       *EREN BOT*
╠════════════════════


〘 👉👉👉💧PARA ADM E O BOT ADM💧 〙✪══


👉 .linkgroup
👉 .marcar membros geral 
👉 .kick @nome  BOT DA BAN
👉 .add @nome  adiciona membro
👉 .promote @ nome da adm
👉 .demote @nome tira adm
👉 .ocr tira texto de foto
👉 .welcome /1 ativar / 0 desligar

〘👉👉👉 💧CRIAÇAO 〙✪══

👉 .sticker  “CRIAR FIGURINHA”
👉 .toimg  “ figurinha virar foto”

〘 👉👉👉💧ANIME💧 〙✪══

👉 .loli
👉 .wait
👉 .lofi
👉 .akeno
👉 .nsfwloli
👉 .loli1

〘 Eren 👻 BOT 〙
}

exports.help = help






