const {
    WAConnection,
    MessageType,
    Presence,
    Mimetype,
    GroupSettingChange
} = require('@adiwajshing/baileys')
const { color, bgcolor } = require('./lib/color')
const { eren } = require('./src/eren')
const { eren1 } = require('./src/eren1')
const { wait, simih, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, close } = require('./lib/functions')
const { fetchJson } = require('./lib/fetcher')
const { recognize } = require('./lib/ocr')
const fs = require('fs')
const moment = require('moment-timezone')
const { exec } = require('child_process')
const kagApi = require('@kagchi/kag-api')
const fetch = require('node-fetch')
const tiktod = require('tiktok-scraper')
const ffmpeg = require('fluent-ffmpeg')
const { removeBackgroundFromImageFile } = require('remove.bg')
const imgbb = require('imgbb-uploader')
const lolis = require('lolis.life')
const loli = new lolis()
const welkom = JSON.parse(fs.readFileSync('./src/welkom.json'))
const nsfw = JSON.parse(fs.readFileSync('./src/nsfw.json'))
const samih = JSON.parse(fs.readFileSync('./src/simi.json'))
prefix = '#'
blocked = []

function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);

  //return pad(hours) + ':' + pad(minutes) + ':' + pad(seconds)
  return `${pad(hours)} Hora ${pad(minutes)} Minuto ${pad(seconds)} Segundo`
}

async function starts() {
	const client = new WAConnection()
	client.logger.level = 'warn'
	console.log(banner.string)
	client.on('qr', () => {
		console.log(color('[','white'), color('!','red'), color(']','white'), color(' Scan the qr code above'))
	})

	fs.existsSync('./BarBar.json') && client.loadAuthInfo('./BarBar.json')
	client.on('connecting', () => {
		start('2', 'Connecting...')
	})
	client.on('open', () => {
		success('2', 'Connected')
	})
	await client.connect({timeoutMs: 30*1000})
        fs.writeFileSync('./BarBar.json', JSON.stringify(client.base64EncodedAuthInfo(), null, '\t'))

	client.on('group-participants-update', async (anu) => {
		if (!welkom.includes(anu.jid)) return
		try {
			const mdata = await client.groupMetadata(anu.jid)
			console.log(anu)
			if (anu.action == 'add') {
				num = anu.participants[0]
				try {
					ppimg = await client.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `Olá @${num.split('@')[0]}\nBem vindo ao grupo *${mdata.subject}*\nPor favor não seja um ghost❤️`
				let buff = await getBuffer(ppimg)
				client.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			} else if (anu.action == 'remove') {
				num = anu.participants[0]
				try {
					ppimg = await client.getProfilePicture(`${num.split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `Tchau @${num.split('@')[0]} ja foi tarde 😂👋`
				let buff = await getBuffer(ppimg)
				client.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			}
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})

	client.on('CB:Blocklist', json => {
            if (blocked.length > 2) return
	    for (let i of json[1].blocklist) {
	    	blocked.push(i.replace('c.us','s.whatsapp.net'))
	    }
	})

	client.on('chat-update', async (mek) => {
		try {
                        if (!mek.hasNewMessage) return
                        mek = JSON.parse(JSON.stringify(mek)).messages[0]
			if (!mek.message) return
			if (mek.key && mek.key.remoteJid == 'status@broadcast') return
			if (mek.key.fromMe) return
			global.prefix
			global.blocked
			const content = JSON.stringify(mek.message)
			const from = mek.key.remoteJid
			const type = Object.keys(mek.message)[0]
			const apiKey = 'Your-Api-Key'
			const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
			const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
			body = (type === 'conversation' && mek.message.conversation.startsWith(prefix)) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption.startsWith(prefix) ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption.startsWith(prefix) ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text.startsWith(prefix) ? mek.message.extendedTextMessage.text : ''
			budy = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
			const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
			const args = body.trim().split(/ +/).slice(1)
			const isCmd = body.startsWith(prefix)

			mess = {
				wait: '⌛ Espera ai, ... ⌛',
				success: '✔️ Deu certo, ufa kk ✔️',
				error: {
					stick: '⚠️ Falha, ocorreu um erro ao converter a imagem em figurinha ⚠️',
					Iv: '❌ Link tidak valid ❌'
				},
				only: {
					group: '❌ Este comando só pode ser usado em grupos! ❌',
					ownerG: '⚠️ Este comando só pode ser usado pelo dono do bot! 😂',
					ownerB: '❌ Este comando só pode ser usado pelo proprietário do bot! ❌',
					admin: '⚠️ Este comando só pode ser usado por admins! 😝',
					Badmin: '❌ Este comando só pode ser usado quando o bot se torna um administrador! ❌'
				}
			}

			const botNumber = client.user.jid
			const ownerNumber = [";;;"] // replace this with your number
			const isGroup = from.endsWith('@g.us')
			const sender = isGroup ? mek.participant : mek.key.remoteJid
			const groupMetadata = isGroup ? await client.groupMetadata(from) : ''
			const groupName = isGroup ? groupMetadata.subject : ''
			const groupId = isGroup ? groupMetadata.jid : ''
			const groupMembers = isGroup ? groupMetadata.participants : ''
			const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
			const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
			const isGroupAdmins = groupAdmins.includes(sender) || false
			const isWelkom = isGroup ? welkom.includes(from) : false
			const isNsfw = isGroup ? nsfw.includes(from) : true
			const isSimi = isGroup ? samih.includes(from) : false
			const isOwner = ownerNumber.includes(sender)
			const isUrl = (url) => {
			    return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
			}
			const reply = (teks) => {
				client.sendMessage(from, teks, text, {quoted:mek})
			}
			const sendMess = (hehe, teks) => {
				client.sendMessage(hehe, teks, text)
			}
			const mentions = (teks, memberr, id) => {
				(id == null || id == undefined || id == false) ? client.sendMessage(from, teks.trim(), extendedText, {contextInfo: {"mentionedJid": memberr}}) : client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": memberr}})
			}

			colors = ['red','white','black','blue','yellow','green']
			const isMedia = (type === 'imageMessage' || type === 'videoMessage')
			const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
			const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
			const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
			if (!isGroup && isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
			if (!isGroup && !isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
			if (isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
			if (!isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
			switch(command) {
				case 'eren':
				case 'eren':
					client.sendMessage(from, eren(prefix), text)
					break
					case 'eren1':
				case 'eren1':
					client.sendMessage(from, eren1(prefix), text)
					break
				case 'info':
					me = client.user
					uptime = process.uptime()
					teks = `*Nome do bot* : ${me.name}\n*Número do bot* : @${me.jid.split('@')[0]}\n*Prefix* : ${prefix}\n*Contato de bloqueio total* : ${blocked.length}\n*O bot está ativo em* : ${kyun(uptime)}`
					buffer = await getBuffer(me.imgUrl)
					client.sendMessage(from, buffer, image, {caption: teks, contextInfo:{mentionedJid: [me.jid]}})
					break
				case 'blocklist':
					teks = 'Esta é a lista de números bloqueados :\n'
					for (let block of blocked) {
						teks += `~> @${block.split('@')[0]}\n`
					}
					teks += `Total : ${blocked.length}`
					client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": blocked}})
					break
				case 'ocr':
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await client.downloadAndSaveMediaMessage(encmedia)
						reply(mess.wait)
						await recognize(media, {lang: 'eng+ind', oem: 1, psm: 3})
							.then(teks => {
								reply(teks.trim())
								fs.unlinkSync(media)
							})
							.catch(err => {
								reply(err.message)
								fs.unlinkSync(media)
							})
					} else {
						reply('Só uma foto')
					}
					break
				case 'stiker':
				case 'sticker':
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await client.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.input(media)
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								reply(mess.error.stick)
							})
							.on('end', function () {
								console.log('Finish')
								client.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
								fs.unlinkSync(media)
								fs.unlinkSync(ran)
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
						const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await client.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						reply(mess.wait)
						await ffmpeg(`./${media}`)
							.inputFormat(media.split('.')[1])
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								tipe = media.endsWith('.mp4') ? 'video' : 'gif'
								reply(`❌ Falha ao converter ${tipe} para figurinha`)
							})
							.on('end', function () {
								console.log('Finish')
								client.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
								fs.unlinkSync(media)
								fs.unlinkSync(ran)
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia || isQuotedImage) && args[0] == 'nobg') {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await client.downloadAndSaveMediaMessage(encmedia)
						ranw = getRandom('.webp')
						ranp = getRandom('.png')
						reply(mess.wait)
						keyrmbg = 'Your-ApiKey'
						await removeBackgroundFromImageFile({path: media, apiKey: keyrmbg.result, size: 'auto', type: 'auto', ranp}).then(res => {
							fs.unlinkSync(media)
							let buffer = Buffer.from(res.base64img, 'base64')
							fs.writeFileSync(ranp, buffer, (err) => {
								if (err) return reply('Falha, ocorreu um erro, tente novamente mais tarde.')
							})
							exec(`ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${ranw}`, (err) => {
								fs.unlinkSync(ranp)
								if (err) return reply(mess.error.stick)
								client.sendMessage(from, fs.readFileSync(ranw), sticker, {quoted: mek})
							})
						})
					/*} else if ((isMedia || isQuotedImage) && colors.includes(args[0])) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await client.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.on('start', function (cmd) {
								console.log('Started :', cmd)
							})
							.on('error', function (err) {
								fs.unlinkSync(media)
								console.log('Error :', err)
							})
							.on('end', function () {
								console.log('Finish')
								fs.unlinkSync(media)
								client.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
								fs.unlinkSync(ran)
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=${args[0]}@0.0, split [a][b]; [a] palettegen=reserve_transparent=off; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)*/
					} else {
						reply(`Envie fotos com legendas ${prefix}sticker ou tags de imagem que já foram enviadas`)
					}
					break
				case 'gtts':
					if (args.length < 1) return client.sendMessage(from, 'Qual o código de idioma, cara?', text, {quoted: mek})
					const gtts = require('./lib/gtts')(args[0])
					if (args.length < 2) return client.sendMessage(from, 'Cadê o texto tio', text, {quoted: mek})
					dtt = body.slice(9)
					ranm = getRandom('.mp3')
					rano = getRandom('.ogg')
					dtt.length > 600
					? reply('A maior parte do texto é merda tio')
					: gtts.save(ranm, dtt, function() {
						client.sendMessage(from, fs.readFileSync(ranm), audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
						fs.unlinkSync(rano)
					})
					break
				case 'meme':
					meme = await kagApi.memes()
					buffer = await getBuffer(`https://imgur.com/${meme.hash}.jpg`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: '.......'})
					break
				case 'porno':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSx3BgnL2qAHDTlfCPMAvdjuLGvOx402dSdhw&usqp=CAU`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: 'Adm proibiu porno no gp🙄'})
					break
				case 'dono':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://i.pinimg.com/564x/f3/dc/5e/f3dc5e01fdd7b900046c5dbc3a68d99c.jpg`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: '*CRIADOR:* EREN\:* \n*WPP:*  https://wa.me/5511962667049\n*INSTA:* ...\n\n\n*Digite *.bot* para ver comandos basicos para criar um bot'})
					break
				case 'belle2':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://4.bp.blogspot.com/-pBwX3-rdXeM/XwTW_9oT_9I/AAAAAAAAPt4/_jmeK-lOJMoE4gPYvhgFqzOp-uKnNN9ygCLcBGAsYHQ/s1600/boabronha_2.jpg`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: 'slc'})
					break
				case 'belle3':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://i.pinimg.com/236x/bc/6a/09/bc6a09b526c025c2a9d9e3b961449f26.jpg`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: 'olha p isso mano, pqp '})
					break
				case 'akeno':
					meme = await kagApi.memes()
					buffer = await getBuffer(`https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnFAocqaur5ZX1DPN6ZGP8PJy2cNppas_gYA&usqp=CAU`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: '.......'})
					break
				case 'loli1':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://i.pinimg.com/236x/f1/ff/49/f1ff497285bba6c7831897f210a71b8a.jpg`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: 'hmm, então quer ver loli?'})
					break
				case 'hentai':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQUU8c4NGVqPJifWLULbt9ULF2WY83-NSsYfw&usqp=CAU`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: 'A

01: A Heat for All Seasons
02: A Size Classmate
03: Accelerando Datenshi-tachi no Sasayaki
04: Ai Kyan Joukan
05: Ai no Katachi
06: Ail Maniax
07: Aisai Nikki 
08: Akebi no Hana Maho
09: Akina to Onsen de H Shiyo
10: Alignment You! You!
11: Allargando The Animation 
12: Amanee! 
13: Ana no Oku no Ii Tokoro 
14: Anata dake Konbanwa
15: Anata no Shiranai Kangofu
16: Anata wa Watashi no Mono -
17: Ane Chijo Max Heart
18: Ane Koi Suki Kirai Daisuki
19: Ane Kyun!
20: Ane Yome Quartet
21: Aneimo
22: Aneki no Kounai Kaikinbi
23: Aniki no Yome-san nara, Ore ni Hamerarete Hiihii Itteru Tokoro Da yo
24: Aneki no Kounai Kaikinbi 
25: Aniyome wa Ijippari
26: Anoko to Iikoto
27: Arubaito Shiyou!!
28: Ayatsuri Haramase Dream Note

B

29: Baka na Imouto
30: Babuka Gokudou no Tsuma
31: Baka Dakedo Chinchin Shaburu no Dake wa Jouzu na Chii-chan
32: Bakunyuu BOMB
33: Bakunyuu Maid Kari
34: Betsuni Anta no Tame ni Ookiku Nattan Janain Dakarane!!
35: Bikyaku Seidou Kaichou Ai
36: Binkan Athlete
37: Bloods Inraku no Ketsuzoku 2
38: Boku dake no Hentai Kanojo Motto The Animation
39: Boku no Yayoi-san
40: Boku to Nurse no Kenshuu Nisshi
41: Bokura no Sex
42: Boy Meets Harem The Animation 
43: Brandish
44: Busou Shoujotai Blade Briders The Animation
45: Bust to Bust
46: Buta no Gotoki Sanzoku ni Torawarete Shojo wo Ubawareru Kyonyuu Himekishi & Onna Senshi The Animation

C

47: Cafe Junkie
48: Cartagra
49: Cherry & Gals
50: Chicchana Onaka
51: Chichi-iro Toiki 
52: Chijoku no Seifuku
53: Chijoku Shinsatsushitsu
54: Chikan no Licence
55: Chikan Shita Joshikousei to Sonogo 
56: Chinetsu Karte The Devilish Cherry
57: Chu Shite Agechau Oshikake Onee-san no Seikou Chiryou
58: Colosseum no Senki Another Story 
59: Cosplay Rakuen 
60: Cosplay Roshutsu Kenkyuukai
61: Creamy Pie
62: Crimson Girls Chikan Shihai

D

63: D-Spray
64: Dainiji Ura Nyuugakushiken
65: Daisuki na Haha
66: Daraku Reijou The Animation Hakoiri Ojousama Netorare Choukyou Kiroku
67: Dark Blue
68: Dekakute Ecchi na Ore no Ane
69: Demon Busters Ecchi na Ecchi na Demon Taiji The Animation
70: Demonion Gaiden
71: Diabolus Kikoku
72: Do S na Seitokaichou-sama ga M Note ni Shihai Saremashita
73: Dokidoki Little Ooyasan
74: Dokidoki Oyako Lesson
75: Dorei Usagi To Anthony
76: Dropout

E

77: Ecchi na Shintai Sokutei Anime Edition
78: Eisai Kyoiku
79: Elf no Futagohime Willan to Arsura
80: Elf no Oshiego to Sensei
81: Enbi
82: Enbo E H M
83: Energy Kyouka!!
84: Enkou JK Bitch Gal Ojisan to Namapako Seikatsu
85: Enkou Shoujo Rikujoubu Yukki no Baai The Animation
86: Enyoku
87: Ero Manga! H mo Manga mo Step-up
88: Ero Semi Ecchi ni Yaruki ni ABC The Animation
89: Ero-manga Mitai na Koi Shiyou
90: Eroge! H mo Game mo Kaihatsu Zanmai -
91: Eromame
92: Etsuraku no Tane
93: Euphoria

F

94: Fault!!
95: Fault!! Service Aratanaru Rival
96: Fella Hame Lips
97: Fighting of Ecstasy
98: First Love 
99: Floating Material 
100: Front Innocent
101: Fukubiki! Triangle Futaba wa Atafuta
102: Furifure 2
103: Furifure The Animation
104: Furueru Kuchibiru
105: Furyou ni Hamerarete Jusei Suru Kyonyuu Okaa-san The Animation
106: Fuurinkanzan

G

107: Gaki ni Modotte Yarinaoshi
108: Gakuen 3 
109: Gakuen de Jikan yo Tomare
110: Gakuen no Ikenie
111: Gakuen Saimin Reido
112: Garden The Animation
113: Genkaku Cool na Sensei ga Aheboteochi! 
114: Gibo no Toki
115: Gogo no Kouchou Junai Mellow Yori
116: Green Eyes Ane Kyun! yori The Animation
117: Grope Yami no Naka no Kotoritachi
118: Gyakuten Majo Saiban Chijo na Majo ni Sabakarechau The Animation

H

119: Hachishaku Hachiwa Keraku Meguri Igyou Kaikitan The Animation
120: Haha Sange (Step MILF)
121: Haitoku Tsuma
122: Haramasete Seiryuu-kun!
123: Harem Time The Animation
124: Harukoi Otome
125: Hasan de Ageru 
126: Hataraku Otona no Renai Jijou
127: Hatsujou Switch
128: Heartful Maman The Animation
129: HHH Triple Ecchi
130: Hime-sama Gentei! (Princess Limited!)
131: Himekishi Angelica The Animation
132: Himekishi Lilia
133: Himekishi Olivia 
134: Hishoka Drop The Animation
135: Hissatsu Chikan Nin
136: Hitoriga The Animation 
137: Hitou Meguri Kakure Yu
138: Hitou Meguri Kakure Yu Mao Hen
139: Hitou Meguri The Animation
140: Hitozuma Cosplay Kissa 2 Hitozuma LoveLove
141: Hitozuma Kasumi-san
142: Hitozuma Koukan Nikki
143: Hitozuma Life One Time Gal
144: Hitozuma Ryoujoku Sankanbi
145: Honoo no Haramase Doukyuusei
146: Honoo no Haramase Motto! Hatsuiku! Karada Sokutei 2
147: Honoo no Haramase Oppai Ero Appli Gakuen The Animation
148: Honoo no Haramase Paidol My Star Gakuen Z The Animation
149: Hontou ni Atta Joshi Asuka
150: Houkago 2 Sayuri
151: Houkago 2 The Animation
152: Houkago Initiation
153: Houkago no Yuutousei
154: Houkago NyanNyan 
155: Hump Bang!
156: Hyoudou Ibuki Kanpeki Ibuki Kaichou ga Kousoku Do M! na Wake

I

157: Ichigo Chocola Flavor
158: Ichinen Buri no The Animation
159: Ienai Koto
160: Iinari! Saimin Kanojo
161: Iizuka-senpai x Blazer Ane Kyun! yori The Animation
162: Ijou Chitai Jikken Dorei
163: ikenai Koto
164: Ikkyuu Nyuukon
165: Ikoku na Retro
166: Imakara Atashi
167: Imako System
168: Imouto Bitch ni Shiboraretai
169: Imouto de Ikou! 
170: Imouto Paradise! 2
171: Imouto Paradise! 3 The Animation
172: Imouto to Sono Yuujin ga Ero Sugite Ore no Kokan ga Yabai
173: Implicity
174: In no Houteishiki
175: Inda no Himekishi Janne The Animation
176: Inmu Gakuen Inmu ni Torawareta Bijin Shimai
177: Innocent Blue
178: Innocent Shoujo Memoria 
179: Inshitsu Otaku ni Ikareru Kanojo
180: Inyutsu no Yakata The Animation
181: Issho ni Ecchi
182: Itadaki! Seieki
183: Itazura the Animation

J

184: Jewelry The Animation
185: Jitaku Keibiin
186: JK Bitch ni Shiboraretai
187: JK to Ero Giin Sensei
188: JK to Ero Konbini Tenchou
189: JK to Inkou Kyoushi 4
190: JK to Inkou Kyoushi 4 feat. Ero Giin-sensei
191: JK to Orc Heidan Aku Buta Oni ni Ryougyaku Sareta Seijo Gakuen
192: Jokei Kazoku III Himitsu
193: Jokei Kazoku Inbou
194: Joshikousei no Koshitsuki
195: Jukujo Shigan
196: Junai Maniac
197: Junjou Shoujo Et Cetera
198: Junk Land The Animation
199: Jutaijima
200: Juvenile Pornography

K

201: Kafun Shoujo Chuuihou! The Animation
202: Kagachi-sama Onagusame Tatematsurimasu The Animation
203: Kagirohi Shaku Kei - Another
204: Kakushi Dere
205: Kangoku Injoku no Jikkentou
206: Kanojo ga Mimai ni Konai Wake
207: Kanojo ga Nekomimi ni Kigaetara 
208: Kanojo wa Dare to Demo Sex Suru
209: Kanojo x Kanojo x Kanojo
210: Kanpeki Ojou-sama no Watakushi
211: Kansen 5 The Daybreak
213: Kansen Ball Buster
214: Kansen Inyoku no Rensa
215: Kansen Sodom
216: Katainaka ni Totsui de Kita Russia Musume to H Shimakuru Ohanashi
217: Katekano Idol Sister
218: Kedamono-tachi no Sumu Ie de
219: Kime Koi!
220: Kimi no Mana wa Rina Witch
221: Kimi no na wo Yobeba Kindan no Byoutou
222: Kindan no Byoutou The Animation
223: Kiniitta Chitsu ni Ikinari Nakadashi OK na Resort-tou
224: Kininaru Roommate
225: Kiriya Hakushakuke no Roku Shimai
226: Koakuma Kanojo The Animation
227: Koi Maguwai
228: Koiito Kinenbi The Animation
229: Koikishi Purely Kiss The Animation
230: Koinaka Koinaka de Hatsukoi x Nakadashi
231: Konna ni Yasashiku Sareta no
232: Kotowari Kimi no Kokoro no Koboreta Kakera
233: Koukai Benjo The Animation
234: Kowaku no Toki
235: Kowaremono Risa Plus The Animation
236: Kowaremono Risa The Animation
237: Kowaremono The Animation
238: Kunoichi Botan
239: Kunoichi Sakuya
240: Kuraibito
241: Kuro Ai
242: Kuro no Kyoushitsu
243: Kurohime Shikkoku no Yakata
244: Kuroinu K S wa H ni S
245: Kurutta Kyoutou Danzai no Gakuen
246: Kyonyuu Daikazoku Saimin
247 Kyonyuu Dosukebe Gakuen
248 Kyonyuu Fantasy 249Kyonyuu Hitozuma Onna Kyoushi Saimin
250 Kyonyuu JK ga Ojisan Chinpo
251 Kyonyuu Kazoku Saimin
252 Kyonyuu Reijou MC Gakuen
253 Kyonyuu Try! Tanki Shuuchuu Chichi Momi Lesson
254 Kyouiku Shidou The Animation
255 Kyuuketsuki!!
L 
256 Last Waltz Hakudaku Mamire no Natsu Gasshuku
257 Lilitales
258 Little Monica Monogatari
259 Lo Re Pako Sukusuku Mizuki-chan The Animation
260 Love 2 Quad
261 Love B Yasashii Onna 
262 Love Colon
263 Love es M The Animation
264 Love Selection The Animation
265 Lovely Day Boku to Kanojo no Nana Nichikan
266 Lovely x Cation The Animation 
M 
267 M Ogui Last Order
268 Ma ga Ochiru Yoru
269 Machi Gurumi no Wana
270 Madonna Kanjuku Body Collection
271 Magical Moe
272 Maid Ane
273 Maid-san to Boin Damashii The Animation
274 Makai Kishi Ingrid Re
275 Maken no Hime wa Ero Ero Desu
276 Maki-chan to Nau
277 Mama Puri!
278 Manin Densha
279 Mankitsu Happening 
280 Maple Colors
281 Maro no Kanja wa Gatenkei
282 Marriage Blue
283 Marshmallow Imouto Succubus
284 Mayoiga no oneesan
285 Megachu!
286 Meikoku Gakuen Jutai-hen
287 Mejoku
288 Menhera Ayuri no Yamanai Onedari Headphone wa Hazusenai
289 Mesu Kyoushi 4 Kegasareta Kyoudan
290 Mesu Nochi Torare
291 Miboujin Nikki The Animation
292 Misuzu Ikenai Koto
293 Miyazaki Maya Daizukan
294 Mizugi Kanojo The Animation
295 Mofukuzuma
296 Mokkai Shiyo
297 Momoiro Bouenkyou Anime Edition
298 Momoiro Milk 
299 Monmusu Quest!
300 Mou Hasamazu ni wa Irarenai Hoshi ni Onegai Shitara Konna ni Okkiku Nacchatta!
301 Mozu no Nie
302 Mrs. Junkie 
303 Muchi Muchi Kyousei Seichouchuu!!!
304 Muma no Machi Cornelica
305 Musuko no Tomodachi ni Okasarete
306 Muttsuri Dosukebe Tsuyu Gibo Shimai no Honshitsu Minuite Sex Sanmai
307 My Imouto Koakuma na A Cup
N 
308 Naisho no Wakana-san
309 Nama Lo Re Furachimono The Animation
310 Nama Lo Re Namakemono The Animation
311 Namaiki Kissuisou e Youkoso! The Animation
312 Namanaka Hyaku Percent! Katamusubi no Shinpa
313 Nariyuki Papakatsu Girls!! The Animation
314 Natsumushi The Animation
315 Natural Vacation
316 Nee Summer!
317 Nee, ...Shiyo
318 Nerawareta Megami Tenshi Angeltia Mamotta Ningentachi ni Uragirarete
319 Netorare Fighter Yaricchingu!
320 Netorare Tanabe Yuuka no Dokuhaku
321 Netorare Zuma
322 Netoraserare
323 Newmanoid
324 Niizuma Koyomi The Animation
325 Niku Mesu R30 The Animation
326 Nikuyome T Ke no H
327 Nosewasure
328 Nudist Beach ni Shuugakuryokou de!! The Animation
329 Nuki Doki! Tenshi to Akuma no Sakusei Battle
330 Nuresuke JK Ameyadori R 
O 
331 Oide yo! Mizuryuu Kei Land
332 Oide yo! Shiritsu Yarimakuri Gakuen
333 Ojousama wa H ga Osuki
334 Ojousama Yomeiri Kousou! 
335 Okusama wa Moto Yariman
336 Oni Chichi 1
337 Oni Chichi 2
338 Oppai Gakuen Marching Band Bu!
339 Oppai Heart Kanojo wa Kedamono Hatsujouki
340 Oppai Infinity The Animation
341 Oppai no Ouja 48
342 Ore ga Kanojo o Okasu Wake 
343 Ore wa Kanojo o Shinjiteru!
344 Oshaburi Announcer
345 Oshiete Re Maid
346 Oshioki Gakuen Reijou Kousei Keikaku
347 Otoko no Ko Ojousama
348 Otome Chibaku Yuugi
349 Otome Domain The Animation 
350 Otome Dori
351 Otome Hime
352 Otome Juurin Yuugi Maiden Infringement Play
353 Oyako Rankan The Animation
354 Oyasumi Sex
355 Oyome-sama Honey Days
P 
356 Paizuri Cheerleader vs. Sakunyuu Ouendan!
357 Pakomane Watashi, Kyou kara Meimon Yakyuubu no Seishorigakari ni Narimasu... The Animation
358 Papa Love
359 Pet Life 
360 Pinkerton 
361 Pisu Hame!
362 Please Rape Me!
363 Pretty x Cation The Animation
364 Pretty x Cation 2 The Animation
365 Princess Lover! 
366 Pure Heart Shooting Girl
R 
367 Ran-Sem Hakudaku Delmo Tsuma no Miira Tori
368 Rance 01 Hikari wo Motomete The Animation
369 Rankou Choukyou Maid ni Natta Shoujo
370 Rape Gouhouka!!!
371 Rasen Sokou no Dystopia
372 Real Eroge Situation! The Animation
373 Rei Zero 
374 Renai Fuyou Gakuha
375 Renketsu Houshiki
376 Rennyuu Tales The Animation
377 Rensa Byoutou
378 Residence
379 Resort Boin
380 Reunion
381 Rin x Sen + Ran - Sem Cross Mix
382 Rin x Sen Hakudaku Onna Kyoushi to Yaroudomo
383 Ringetsu The Animation
384 Rinkan Biyaku Chuudoku Nigeba Nashi! 1428-nin no Seito Zenin ni Sex Sareru Reijou Sayaka
385 Rinkan club 
386 Romance wa Tsurugi no Kagayaki II
387 Rune Pharmacy
388 Ryou Seibai! Gakuen Bishoujo Seisai Hiroku
389 Ryoujoku Famiresu Choukyou Menu
S 
390 Sagurare Otome The Animation
391 Saimin Class
392 Saimin Gakuen (2018)
393 Saimin Jutsu Zero 
394 Saimin Jutsu 2nd
395 Saimin Seishidou 
396 Saishuu Chikan Densha Next
397 School 
398 Secret Journey
399 Sei Brunehilde Gakuen Shoujo Kishidan to Junpaku no Panty The Animation
400 Sei Shoujo The Animation
401 Sei Yariman Gakuen Enkou Nikki
402 Sei Yariman Sisters Pakopako Nikki The Animation 
403 Seikatsu Shidou!! Anime Edition
404 Seikou! Osananajimi wa Terekusasou ni Uso wo Tsuku
405 Seikoujo Haitoku no Biden Dorei 
406 Seiso de Majime na Kanojo ga Saikyou Yaricir ni Kanyuu Saretara. The Animation
407 Sentakuya Shin-chan
408 Shabura Rental 
409 Shiiba-san no Ura no Kao. with Imouto Lip
410 Shiiku x Kanojo Tenshi no Kousoku-hen
411 Shikkoku no Shaga The Animation
412 Shin Hitou Meguri 
413 Shin Ringetsu
414 Shin Saishuu Chikan Densha
415 Shin Sei Yariman Gakuen Enkou Nikki
416 Shinkyoku no Grimoire The Animation
417 Shiofuki Mermaid
418 Shishunki Shoujo 
419 Shocking Pink
420 Shoujo Kara Shoujo e...
421 Shoujo Kyouiku
422 Shoujo Ramune
423 Shoujo x Shoujo x Shoujo
424 Shoujo-tachi no Sadism The Animation
425 Shoukoujo The Animation
426 Shoyonoido Mako-chan
427 Soikano Gyutto Dakishimete The Animation
428 Sora no Iro, Mizu no Iro
430 Soredemo Tsuma wo Aishiteru
431 Soredemo Tsuma o Aishiteru 2
432 Soukan Yuugi 
433 Soukou Kijo Iris 
434 Soushisouai Note The Animation
435 Spocon! 
436 Starless
437 Stretta The Animation
538 Stringendo Angel-tachi no Private Lesson
439 Stringendo+Accelerando Ultimatum Sera 
440 Succuba Mist Story 
441 Suki de, Suki de, Suki de The Animation
442 Swamp Stamp Anime Edition
443 Sweet Home H na Oneesan wa Suki Desu ka
T 
444 T.K.G � Takagi 
445 Taimanin Yukikaze
446 Tamashii Insert 
447 Tayu Tayu
448 Teakamamire no Tenshi The Animation
449 Tenioha! 
450 Tennen Koi-iro Alcohol
451 Tensei Kendo no Harem Colosseo
452 Tentacle and Witches
453 The Guts!
454 Tinderbox
455 Tiny Evil
456 Tony�s Heroine Series Kanojo wa Hanayome Kouhosei
457 Toriko Hime Hakudaku Mamire no Reijou
458 Toriko no Chigiri 
459 Toriko no Kusari
460 Toshi Densetsu Series
461 Triangle Blue
462 Tropical Kiss
463 True Blue
464 True Blue Gaiden 
465 TSF Monogatari
466 Tsugou no Yoi Sexfriend
467 Tsuma ga Onsen de Circle Nakama no Nikubenki ni Natta no Desu ga... Anime Edition
468 Tsuma Netori Ryoujoku Rinne
469 Tsuma Shibori 
470 Tsumamigui 
471 Tsumamigui 3 The Animation
472 Tsun M! Gyutto Shibatte Shidoushite The Animation
473 Tsun Tsun Maid wa Ero Ero Desu
474 Tsundere Inran Shoujo Sukumi
475 Tsunpuri
U 
476 Uhou Renka
477 Unsweet Netorare Ochita Onna-tachi
478 Ura Jutaijima
V 
479 Valkyrie Choukyou Semen Tank no Ikusa Otome 10-nin Shimai
480 Venus Blood BRAVE
481 Victorian Maid Maria no Houshi
W 
482 Wagaya no Liliana-san
483 Waisetsu Missile The Animation
484 Wana Hakudaku Mamire no Houkago
485 Wanna. SpartanSex Spermax!!!
486 Warau Kangofu
487 Watashi ga Toriko ni Natte Yaru
488 Watashi no Shiranai Mesu no Kao
489 Watashi wa Kairaku Izonshou
490 Wizard Girl Ambitious
Y 
491 Yabai! Fukushuu Yami Site
492 Yakata Kannou Kitan
493 Yareruko! Densha Ecchi
494 Yarimoku Beach ni Shuugakuryokou de!!
495 Yobai Suru Shichinin no Harame
496 Yokorenbo Immoral Mother
497 Yokujou Bazooka the Animation
498 Youkoso! Sukebe Elf no Mori e
499 Yume Kui Tsurumiku Shiki Game Seisaku
Z 
500Zecchou Rocket 
501 Zettai Junshu Kyousei Kozukuri Kyokashou!!
502 Zoku Tsuma Netori
503: Zton Jingai Animation A Beautiful Greed Nulu Nulu
504: Zutto Suki Datta'})
					break
				case 'bomdia':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://i.imgur.com/7VL9cFf.jpg`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: 'Bom dia, vcs sao fodas ❤️'})
					break
				case 'boatarde':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://i.imgur.com/JaO3yoV.jpg`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: 'Boa tarde, rapeize 😎👍'})
					break
				case 'boanoite':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://i.imgur.com/yOFxSUR.jpg`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: 'Boa noite fml ❤️'})
					break
				case 'belle':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZu6GwgURUgkuWZXOq-KPLRvA5LOezhvY_VQ&usqp=CAU`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: '👀️'})
					break
				case 'belle1':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQ7ot6RZPnXSJFFKVjPoeXHjTYyi6uk5W_mA&usqp=CAU`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: '👀️'})
					break
				case 'mia':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQaKeXU5ryvFTNz6nJm9cioGCoeqlZQSh1Mgw&usqp=CAU`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: '👀️'})
					break
				case 'lofi':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTL9hZBPRo16fIhsIus3t1je2oAU23pQqBpfw&usqp=CAU`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: '️💆'})
					break
				case 'malkova':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtbo5EcVSGj-IvEVznHIgMZ9vjFptZfvprtg&usqp=CAU`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: '️💆'})
					break
													                case 'mia1':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRjVCGkGDxARumfloekQMCazM8uvpj2AgW2lg&usqp=CAU`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: '👀️'})
					break
				case 'nsfwloli':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJhzKetbU3pzhoZdaIo6qBklCzwvmCCOznbg&usqp=CAU`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: 'Rum️'})
					break
				case 'reislin':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRp_f4rTII-Gbkpc8GINsW-gKtIpeozf6sSuQ&usqp=CAU`)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: '🤭'})
					break
				case 'mia2':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://i.gifer.com/7udO.gif`)
					client.sendMessage(from, buffer, video, {quoted: mek, caption: 'use o .sticker para ver o gif da mia️'})
					break
				case 'setprefix':
					if (args.length < 1) return
					if (!isOwner) return reply(mess.only.ownerB)
					prefix = args[0]
					reply(`O prefixo foi alterado com sucesso para : ${prefix}`)
					break
				case 'loli':
					loli.getSFWLoli(async (err, res) => {
						if (err) return reply('❌ *ERROR* ❌')
						buffer = await getBuffer(res.url)
						client.sendMessage(from, buffer, image, {quoted: mek, caption: 'heher boy🙉'})
					})
					break
				case 'nsfwloli':
					if (!isNsfw) return reply('❌ *FALSE* ❌')
					loli.getNSFWLoli(async (err, res) => {
						if (err) return reply('❌ *ERROR* ❌')
						buffer = await getBuffer(res.url)
						client.sendMessage(from, buffer, image, {quoted: mek, caption: '🤭'})
					})
					break
				case 'hilih':
					if (args.length < 1) return reply('Cadê o texto, hum?')
					anu = await fetchJson(`https://mhankbarbars.herokuapp.com/api/hilih?teks=${body.slice(7)}`, {method: 'get'})
					reply(anu.result)
					break
				case 'yt2mp3':
					if (args.length < 1) return reply('Cadê o url, hum?')
					if(!isUrl(args[0]) && !args[0].includes('youtu')) return reply(mess.error.Iv)
					anu = await fetchJson(`https://mhankbarbars.herokuapp.com/api/yta?url=${args[0]}&apiKey=${apiKey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					teks = `*Title* : ${anu.title}\n*Filesize* : ${anu.filesize}`
					thumb = await getBuffer(anu.thumb)
					client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', filename: `${anu.title}.mp3`, quoted: mek})
					break
				case 'ytsearch':
					if (args.length < 1) return reply('O que você está procurando? pau?')
					anu = await fetchJson(`https://mhankbarbars.herokuapp.com/api/ytsearch?q=${body.slice(10)}&apiKey=${apiKey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					teks = '=================\n'
					for (let i of anu.result) {
						teks += `*Title* : ${i.title}\n*Id* : ${i.id}\n*Published* : ${i.publishTime}\n*Duration* : ${i.duration}\n*Views* : ${h2k(i.views)}\n=================\n`
					}
					reply(teks.trim())
					break
				case 'tiktok':
					if (args.length < 1) return reply('Onde está o url, hum?')
					if (!isUrl(args[0]) && !args[0].includes('tiktok.com')) return reply(mess.error.Iv)
					reply(mess.wait)
					anu = await fetchJson(`https://mhankbarbars.herokuapp.com/api/tiktok?url=${args[0]}&apiKey=${apiKey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, video, {quoted: mek})
					break
				case 'nulis':
				case 'tulis':
					if (args.length < 1) return reply('O que você quer escrever??')
					teks = body.slice(7)
					reply(mess.wait)
					anu = await fetchJson(`https://mhankbarbars.herokuapp.com/nulis?text=${teks}&apiKey=${apiKey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					buff = await getBuffer(anu.result)
					client.sendMessage(from, buff, image, {quoted: mek, caption: mess.success})
					break
				case 'url2img':
					tipelist = ['desktop','tablet','mobile']
					if (args.length < 1) return reply('Que tipo é??')
					if (!tipelist.includes(args[0])) return reply('Tipe desktop|tablet|mobile')
					if (args.length < 2) return reply('Cadê o url, hum?')
					if (!isUrl(args[1])) return reply(mess.error.Iv)
					reply(mess.wait)
					anu = await fetchJson(`https://mhankbarbars.herokuapp.com/api/url2image?tipe=${args[0]}&url=${args[1]}&apiKey=${apiKey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					buff = await getBuffer(anu.result)
					client.sendMessage(from, buff, image, {quoted: mek})
					break
				case 'tstiker':
				case 'tsticker':
					if (args.length < 1) return reply('Cadê o texto, hum?')
					ranp = getRandom('.png')
					rano = getRandom('.webp')
					teks = body.slice(9).trim()
					anu = await fetchJson(`https://mhankbarbars.herokuapp.com/api/text2image?text=${teks}&apiKey=${apiKey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						if (err) return reply(mess.error.stick)
						client.sendMessage(from, fs.readFileSync(rano), sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					break
				case 'marcar':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					teks += '\n\n'
					for (let mem of groupMembers) {
						teks += `*Oi seus bostas* @${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
					mentions(teks, members_id, true)
					break
                case 'marcar2':
					members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					teks += '\n\n'
					for (let mem of groupMembers) {
						teks += `╠➥ @${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
					reply(teks)
					break
                 case 'marcar3':
					members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					teks += '\n\n'
					for (let mem of groupMembers) {
						teks += `╠➥ https://wa.me/${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
					client.sendMessage(from, teks, text, {detectLinks: false, quoted: mek})
					break
				case 'limpar':
					if (!isOwner) return reply('Comando so funfa, se você for o dono do bot 😡')
					anu = await client.chats.all()
					client.setMaxListeners(25)
					for (let _ of anu) {
						client.deleteChat(_.jid)
					}
					reply('Excluido todos os chats com sucesso :)')
					break
				case 'ts':
					if (!isOwner) return reply('Quem é você lek?')
					if (args.length < 1) return reply('.......')
					anu = await client.chats.all()
					if (isMedia && !mek.message.videoMessage || isQuotedImage) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						buff = await client.downloadMediaMessage(encmedia)
						for (let _ of anu) {
							client.sendMessage(_.jid, buff, image, {caption: `[ ISSO E UMA TRANSMISSÃO ]\n\n${body.slice(4)}`})
						}
						reply('Transmissão enviada com sucesso')
					} else {
						for (let _ of anu) {
							sendMess(_.jid, `[ ISSO E UMA TRANSMISSÃO ]\n\n${body.slice(4)}`)
						}
						reply('Transmissão enviada com sucesso')
					}
					break
        case 'promote':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = 'Promovido com sucesso\n'
						for (let _ of mentioned) {
							teks += `@${_.split('@')[0]}\n`
						}
						mentions(from, mentioned, true)
						client.groupRemove(from, mentioned)
					} else {
						mentions(`Esse carinha aqui @${mentioned[0].split('@')[0]} agora é admin então respeitem ok?! 😂`, mentioned, true)
						client.groupMakeAdmin(from, mentioned)
					}
					break
				case 'demote':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = 'Rebaixado com sucesso\n'
						for (let _ of mentioned) {
							teks += `@${_.split('@')[0]}\n`
						}
						mentions(teks, mentioned, true)
						client.groupRemove(from, mentioned)
					} else {
						mentions(`Esse carinha aqui @${mentioned[0].split('@')[0]} Acabou de perder o adm pressionem F ai rapaziada 😂!`, mentioned, true)
						client.groupDemoteAdmin(from, mentioned)
					}
					break
				case 'add':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (args.length < 1) return reply('quem você deseja adicionar, um gênio??')
					if (args[0].startsWith('08')) return reply('Use o código do país amigo')
					try {
						num = `${args[0].replace(/ /g, '')}@s.whatsapp.net`
						client.groupAdd(from, [num])
					} catch (e) {
						console.log('Error :', e)
						reply('Falha ao adicionar a pessoa, talvez seja porque é privado')
					}
					break
				case 'kick':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target yang ingin di tendang!')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = 'Pedidos recebidos, emitidos :\n'
						for (let _ of mentioned) {
							teks += `@${_.split('@')[0]}\n`
						}
						mentions(teks, mentioned, true)
						client.groupRemove(from, mentioned)
					} else {
						mentions(`KKKKKKKKKK acabou de levar ban, bobao : @${mentioned[0].split('@')[0]}`, mentioned, true)
						client.groupRemove(from, mentioned)
					}
					break
				case 'listadmins':
					if (!isGroup) return reply(mess.only.group)
					teks = `Lista de admins do grupo *${groupMetadata.subject}*\nTotal : ${groupAdmins.length}\n\n`
					no = 0
					for (let admon of groupAdmins) {
						no += 1
						teks += `[${no.toString()}] @${admon.split('@')[0]}\n`
					}
					mentions(teks, groupAdmins, true)
					break
                                case 'linkgroup':
                                        if (!isGroup) return reply(mess.only.group)
                                        if (!isGroupAdmins) return reply(mess.only.admin)
                                        if (!isBotGroupAdmins) return reply(mess.only.Badmin)
                                        linkgc = await client.groupInviteCode(from)
                                        reply('https://chat.whatsapp.com/'+linkgc)
                                        break
                                case 'leave':
                                        if (!isGroup) return reply(mess.only.group)
                                        if (isGroupAdmins || isOwner) {
                                            client.groupLeave(from)
                                        } else {
                                            reply(mess.only.admin)
                                        }
                                        break
				case 'toimg':
					if (!isQuotedSticker) return reply('❌ responder sticker hum ❌')
					reply(mess.wait)
					encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await client.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.png')
					exec(`ffmpeg -i ${media} ${ran}`, (err) => {
						fs.unlinkSync(media)
						if (err) return reply('❌ Falha ao converter adesivos em imagens ❌')
						buffer = fs.readFileSync(ran)
						client.sendMessage(from, buffer, image, {quoted: mek, caption: '>//<'})
						fs.unlinkSync(ran)
					})
					break
				case 'simi':
					if (args.length < 1) return reply('Textnya mana um?')
					teks = body.slice(5)
					anu = await simih(teks) //fetchJson(`https://mhankbarbars.herokuapp.com/api/samisami?text=${teks}`, {method: 'get'})
					//if (anu.error) return reply('Simi ga tau kak')
					reply(anu)
					break
				case 'simih':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (args.length < 1) return reply('Hmmmm')
					if (Number(args[0]) === 1) {
						if (isSimi) return reply('O modo Simi está ativado')
						samih.push(from)
						fs.writeFileSync('./src/simi.json', JSON.stringify(samih))
						reply('Modo simi ativado com sucesso neste grupo hehe️')
					} else if (Number(args[0]) === 0) {
						samih.splice(from, 1)
						fs.writeFileSync('./src/simi.json', JSON.stringify(samih))
						reply('Modo simi desativado com sucesso neste grupo ✔️')
					} else {
						reply('1 para ativar, 0 para desativar, lerdão você em 🤦')
					}
					break
				case 'welcome':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (args.length < 1) return reply('Hmmmm')
					if (Number(args[0]) === 1) {
						if (isWelkom) return reply('Já ativo um')
						welkom.push(from)
						fs.writeFileSync('./src/welkom.json', JSON.stringify(welkom))
						reply('Ativou com sucesso o recurso de boas-vindas neste grupo ✔️')
					} else if (Number(args[0]) === 0) {
						welkom.splice(from, 1)
						fs.writeFileSync('./src/welkom.json', JSON.stringify(welkom))
						reply('Desativou com sucesso o recurso de boas-vindas neste grupo ✔️')
					} else {
						reply('1 para ativar, 0 para desativar')
					}
                                      break
				case 'clone':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (args.length < 1) return reply('A tag alvo que você deseja clonar')
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag cvk')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					let { jid, id, notify } = groupMembers.find(x => x.jid === mentioned)
					try {
						pp = await client.getProfilePicture(id)
						buffer = await getBuffer(pp)
						client.updateProfilePicture(botNumber, buffer)
						mentions(`Foto profile Berhasil di perbarui menggunakan foto profile @${id.split('@')[0]}`, [jid], true)
					} catch (e) {
						reply('falhou')
					}
					break
				case 'wait':
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						reply(mess.wait)
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						media = await client.downloadMediaMessage(encmedia)
						await wait(media).then(res => {
							client.sendMessage(from, res.video, video, {quoted: mek, caption: res.teks.trim()})
						}).catch(err => {
							reply(err)
						})
					} else {
						reply('Só uma foto')
					}
					break
				default:
					if (isGroup && isSimi && budy != undefined) {
						console.log(budy)
						muehe = await simih(budy)
						console.log(muehe)
						reply(muehe)
					} else {
						console.log(color('[ERROR]','red'), 'Unregistered Command from', color(sender.split('@')[0]))
					}
                           }
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})
}
starts()
